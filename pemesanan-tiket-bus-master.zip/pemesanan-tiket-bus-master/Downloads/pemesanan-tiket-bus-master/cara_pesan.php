<br>
<br>
<br>
<div class="col-md-12">
    <h3 class="page-header">
        <div align="center">Cara Pemesanan Tiket</div>
    </h3>
    <br>
    <br>
    <br>
    <br>	
    <img src="images/help.png" width="1200px" height="600px">
</div>