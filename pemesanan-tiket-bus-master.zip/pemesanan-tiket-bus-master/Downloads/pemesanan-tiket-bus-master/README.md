# Aplikasi Pemesanan Tiket Bus Berbasis Web menggunakan PHP
Aplikasi ini merupakan sebuah sistem pemesanan tiket bus berbasis website, dengan fitur : 
  1. Pemesanan
  2. Konfirmasi Pembayaran
  3. Cetak Tiket
  4. Cek Proses
