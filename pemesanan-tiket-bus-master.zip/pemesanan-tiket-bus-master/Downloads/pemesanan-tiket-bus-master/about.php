<div class="col-md-12">
	<div class="col-md-1">
		
	</div>

	<div class="col-md-10">
		<br><br><br>
		<h3>
			Sejarah Singkat
		</h3>
		<br>
		<p>
			P.O Sumber Alam didirikan pada tahun 1975 sebagai sebuah perusahaan keluarga. Sebelumnya, perusahaan ini mengalami beberapa kali transformasi dalam perkembangannya. Sebelumnya, pada kisaran tahun 1969 terbentuk PO Tresno, yang dirintis oleh ibu Thung Tjie Hing, yang merupakan nenek dari Bapak Judi Setijawan.
		</p>
		<p>
			Pada awal perjalanannya, P.O Sumber Alam hanya menggunakan 6 unit bus untuk melayani trayek dengan tujuan Jakarta – Yogyakarta dan Yogyakarta – Jakarta. Dan pada tahun 1984, adik dan kakak dari Bapak Judi Setijawan Hambali tidak ingin ikut ambil bagian dalam mengembangkan usaha ini. Akhirnya, Bapak Judi Setijawan Hambali meneruskan usaha ini serta dibantu oleh sang istri, Ibu Retno Harlani Judana.
		</p>
		<p>
			Sejak berdirinya, P.O Sumber Alam sudah melayani trayek Antar Kota Antar Provinsi (AKAP) Yogyakarta – Jakarta. Hingga saat ini, P.O Sumber Alam memiliki sekitar 300 unit bus dengan trayek Antar Kota Antar Provinsi (AKAP), dan juga melayani trayek Antar Kota Dalam Provinsi (AKDP) untuk wilayah Yogyakarta. P.O Sumber Alam juga memiliki beberapa uni usaha lain, seperti Rumah Makan dan juga SPBU.
		</p>
		<br><br><br>
		<h3>
			Visi dan Misi
		</h3>
		<br>
		Visi
		<p>
			Menjadi armada angkutan pilihan utama di Indonesia	
		</p>
		<br><br>
		Misi
		<p>
			1.	Menyelenggarakan jasa angkutan darat yang mengutamakan keselamatan, ketepatan waktu dan 		pelayanan yang prima dengan sentuhan keramah-tamahan.
			<br>
			2.	Memaksimalkan pertumbuhan nilai perusahaan, efisiensi dan menyejahterakan pegawai.
			<br>
			3.	Menjadi mitra yang bisa dipercara oleh masyarakat, khususnya pengguna jasa transportasi 		angkutan darat.

		</p>

		
	</div>

	<div class="col-md-1">
		
	</div>
</div>