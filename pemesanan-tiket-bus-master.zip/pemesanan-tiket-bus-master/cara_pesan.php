<div class="col-md-12">
	<h3 class="page-header" align="center">
    	Cara Pemesanan Tiket
	</h3>
	<br><br><br>
</div>